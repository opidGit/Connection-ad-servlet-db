package com.template.bis_android_client;

import java.util.ArrayList;

/**
 * Created by yeongjun-lab on 2014-10-28.
 */
public interface TemplateServiceListener {
    public void onTemplateActionComplete(ArrayList<String> arrayList);
}
