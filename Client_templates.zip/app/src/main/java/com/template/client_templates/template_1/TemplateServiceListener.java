package com.template.client_templates.template_1;

import java.util.ArrayList;

/**
 * Created by yeongjun-lab on 2014-11-03.
 */
public interface TemplateServiceListener {
    public void onTemplateActionComplete(ArrayList<String> arrayList);
}
