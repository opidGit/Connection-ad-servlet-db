package com.template.bis_android_client;

import android.os.AsyncTask;
import android.util.Log;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIUtils;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


public class HTTPSubmit {

    public HTTPSubmit() {
    }

    public void run() {
        new RequestWebServiceTask().execute(null, null, null);
    }


    // AsyncTask<Params,Progress,Result>
    private class RequestWebServiceTask extends AsyncTask<String, Object, HttpResponse> {
        final String APP_TAG = "Request WebService";

        /*
         * 서버 주소
         */
        private String scheme = "http";
        private String host = "203.247.240.62";
        private int port = 80;
        // private String path = "bis_WebAndDBConnecter/main_webConn.jsp";
        private String path = "bis_server/GetUserInfo";
//        private String path = "bis_server/WebContent/collect_location.jsp";

        @Override
        protected HttpResponse doInBackground(String... urls) {

            // 배경 작업을 수행하며 분리된 스레드에서 실행된다. execute 메서드로 전달한 작업거리가
            // params 인수로 전달되는데 여러 개의 인수를 전달할 수 있으므로 배열 타입으로 되어 있다.
            // 하나의 인수만 필요하다면 params[0]만 사용하면 된다.
            // 작업중에 publichProgress 메서드를 호출하여 작업 경과를 UI 스레드로 보고할 수 있다.
            // 최종적으로 작업된 결과를 Result 타입으로 리턴한다.

            HttpResponse response = requestGetHttp();
//            HttpResponse response = requestPostHttp();

            return response;
        }

        @Override
        protected void onPostExecute(HttpResponse result) {
            // 백그다운드 작업이 끝난 후 UI 스레드에서 실행된다. 인수로 작업의 결과가 전달되는데
            // 취소되었거나 예외가 발생했으면 null이 전달된다.
        }

        // Request Get method
        private HttpResponse requestGetHttp() {
            URI uri = null;
            HttpGet httpGet = null;
            HttpResponse response = null;

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//            String currentTime = sdf.format(_userInfo.getDate());
            String currentTime = sdf.format(new Date(System.currentTimeMillis()));

            // 값 추가하기
            ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
            //  nameValuePairs.add(new BasicNameValuePair("id", _userInfo.getId()));
            //nameValuePairs.add(new BasicNameValuePair("latitude", _userInfo.getLatitude() + ""));
            //nameValuePairs.add(new BasicNameValuePair("longitude", _userInfo.getLongitude() + ""));
            nameValuePairs.add(new BasicNameValuePair("date", currentTime));
            String qParams = URLEncodedUtils.format(nameValuePairs, "UTF-8");


            /* 전송하는 부분 */
            // setConnectionTimeout : 클라이언트가 요청을 보냈을 때 서버가 응답하는 시간의 한도 설정
            // 요청이 있지만 서버가 응답이 없는 경우
            // setSoTimeout : 일정시간 클라이언트와 서버와의 교신이 없다면 소켓의 연결을 끊음.
            // 둘 사이에 아무런 요청이나 응답이 없는 경우
            try {
                HttpClient client = new DefaultHttpClient();
                HttpParams params = client.getParams();
                HttpConnectionParams.setConnectionTimeout(params, 5000);
                HttpConnectionParams.setSoTimeout(params, 5000);

                uri = URIUtils.createURI(scheme, host, port, path, qParams, null);
                httpGet = new HttpGet(uri);


                response = client.execute(httpGet); // 발신

                HttpEntity httpEntity = response.getEntity(); // 수신
                String output = EntityUtils.toString(httpEntity);
                System.out.println(output.toString());

            } catch (URISyntaxException e) {
                Log.e("Exception", "URISyntaxException");
            } catch (IOException e) {
                Log.e("Exception", "IOException");
            }


            try {
                if (response.getStatusLine().getStatusCode() == 200) {
                    Log.d(APP_TAG, "HTTP GET succeeded");

                    StringBuilder strBuilder = new StringBuilder();
                    HttpEntity messageEntity = response.getEntity();
                    InputStream is = messageEntity.getContent();
                    BufferedReader br = new BufferedReader(new InputStreamReader(is));
                    String line;
                    while ((line = br.readLine()) != null) {
                        strBuilder.append(line);
                    }
                    Log.d(APP_TAG, strBuilder.toString());
                }
            } catch (Exception e) {

            }


            return response;

        }

        // TODO: post 방식은 아직 실험 안해봄
        private HttpResponse requestPostHttp() {
            HttpResponse response = null;

            return response;
        }
    }


}
